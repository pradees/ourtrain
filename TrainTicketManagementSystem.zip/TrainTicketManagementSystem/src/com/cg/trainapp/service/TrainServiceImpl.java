package com.cg.trainapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.trainapp.bean.TrainBean;
import com.cg.trainapp.dao.ITrainDao;
import com.cg.trainapp.dao.TrainDaoImpl;
import com.cg.trainapp.exception.TrainException;

public class TrainServiceImpl implements ITrainService {
	ITrainDao trainDao;

	@Override
	public String addPassengerDetails(TrainBean train) throws TrainException {
		
		trainDao=new TrainDaoImpl();	
		String ticketSeq;
		ticketSeq= trainDao.addPassengerDetails(train);
		return ticketSeq; 
		
	}

	@Override
	public TrainBean viewBookingDetails(String ticketID) throws TrainException {
		trainDao=new TrainDaoImpl();
		TrainBean bean=null;
		bean=trainDao.viewBookingDetails(ticketID);
		return bean;
	}

	/*@Override
	public List<TrainBean> retrieveAll() throws TrainException {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	public void validateDonor(TrainBean train) throws TrainException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating donor name
		if(!(isValidName(train.getPassengerName()))) {
			validationErrors.add("\n Passenger Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating address
		if(!(isValidAddress(train.getAddress()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(train.getPhoneNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		
		if(!validationErrors.isEmpty())
			throw new TrainException(validationErrors +"");
	}

	
	public boolean isValidName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	
	public boolean validateTicketId(String ticketId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,5}");
		Matcher idMatcher = idPattern.matcher(ticketId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	
}
