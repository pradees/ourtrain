package com.cg.trainapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.trainapp.bean.TrainBean;
import com.cg.trainapp.connection.DBconnection;
import com.cg.trainapp.exception.TrainException;

public class TrainDaoImpl implements ITrainDao{

	
	Logger logger=Logger.getRootLogger();
	public TrainDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	public String addPassengerDetails(TrainBean train) throws TrainException {
		
Connection connection = DBconnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String donorId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(TrainQueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,train.getPassengerName());			
			preparedStatement.setString(2,train.getPhoneNumber());
			preparedStatement.setString(3,train.getAddress());
			preparedStatement.setString(4,train.getDestination());			
			preparedStatement.setDouble(5,train.getTicketPrice());	
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(TrainQueryMapper.TICKETID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new TrainException("Booking failed ");

			}
			else
			{
				logger.info("Booked successfully:");
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new TrainException("Technical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new TrainException("Error in closing db connection");

			}
		}
		
	}

	
	public TrainBean viewBookingDetails(String ticketID) throws TrainException {
Connection connection=DBconnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		TrainBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(TrainQueryMapper.VIEW_BOOKING_DETAILS_QUERY);
			preparedStatement.setString(1,ticketID);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new TrainBean();
				bean.setPassengerName(resultset.getString(1));
				bean.setAddress(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setBookingDate(resultset.getDate(4));
				bean.setDestination(resultset.getString(5));
				bean.setTicketPrice(resultset.getDouble(6));
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new TrainException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new TrainException("Error in closing db connection");

			}
		}
		
	}

	
	/*public List<TrainBean> retrieveAll() throws TrainException {
		// TODO Auto-generated method stub
		return null;
	}*/

	
}
